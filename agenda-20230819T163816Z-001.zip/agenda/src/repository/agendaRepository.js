import conexao from "./connection.js";

export async function listarAgenda() {
    let sql = 'select * from tb_agenda';

    let resp = await conexao.query(sql);
    let dados = resp[0];

    return dados;
}

export async function inserir(agenda) {
    let sql = 'insert into tb_agenda(nm_contato, ds_telefone, ds_email, bt_favorito, dt_cadastro) values(?,?,?,?,?)';

    let resp = await conexao.query(sql, [agenda.contato, agenda.telefone, agenda.email, agenda.favorito, agenda.cadastro])
    let dados = resp[0];

    agenda.id = dados.insertID;
    return agenda;
}